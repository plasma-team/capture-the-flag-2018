#!/usr/bin/env python3

import helper
import sys

class Runner:

    def set_data(self, content):
        for attr, val in content.items():
            setattr(self, attr, val)

    @staticmethod
    def minify_data(*args, **kwargs):
        print('TO-DO')

    @staticmethod
    def validate_data(*args, **kwargs):
        print('TO-DO')

    def execute_method(self, method, data):
        funct = getattr(self, method, None)
        if funct:
            funct(data)

    def run(self):
        if getattr(self, 'activity', False) and getattr(self, 'action', False):
            self.executor = getattr(helper, self.activity)

            if self.action not in ('Write', 'Read', 'ExecuteMethod'):
                return 'Action not found'

            if self.action == 'ExecuteMethod':
                if self.method:
                    self.execute_method(self.method, getattr(self, 'data'))
                    return 'OK'
                else:
                    return 'Method not found'

            if self.activity not in ('VisitorActivity', 'DrugActivity'):
                return 'Activity not found'

            if self.action == 'Write':
                if self.data:
                    if len(self.data) > 30:
                        return 'Data exceed 30'
                    self.executor.write(self.data)
                    return str(self.data)
                else:
                    return 'No data'
            if self.action == 'Read':
                return self.executor.read()

        return 'Something went wrong'


def print_welcome():
    print('Hospital Information System v1')
    print('')
    print('Input Sample:')
    print('   activity=VisitorActivity#action=Write#data=Jack Visit Hospital @2AM')
    print('   activity=DrugActivity#action=Write#data=Jack Buy Cocaine @2AM')
    print('   action=ExecuteMethod#method=ValidateData')

runner = Runner()
print_welcome()
loop = True
while loop:
    inp = input('>> ')
    cmds = inp.split('#')

    content = {}
    for cmd in cmds:
        if '=' not in cmd:
            continue
        key, val = cmd.split('=')
        content[key] = val

    runner.set_data(content)
    print(runner.run())

    sys.stdout.flush()
