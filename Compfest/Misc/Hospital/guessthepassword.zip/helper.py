from os import *

basepath = path.dirname(__file__)


class VisitorActivity:
    @staticmethod
    def write(data):
        filepath = path.abspath(path.join(basepath, 'visitor', 'last_visitor.txt'))
        f = open(filepath, O_CREAT | O_WRONLY)
        write(f, data.encode())
        close(f)

    @staticmethod
    def read():
        filepath = path.abspath(path.join(basepath, 'visitor', 'last_visitor.txt'))
        f = open(filepath, O_RDONLY)
        ret = read(f, 30)
        return ret.decode().strip()


class DrugActivity:
    @staticmethod
    def write(data):
        filepath = path.abspath(path.join(basepath, 'drug', 'last_drug.txt'))
        f = open(filepath, O_CREAT | O_WRONLY)
        write(f, data.encode())
        close(f)

    @staticmethod
    def read():
        filepath = path.abspath(path.join(basepath, 'drug', 'last_drug.txt'))
        f = open(filepath, O_RDONLY)
        ret = read(f, 30)
        return ret.decode().strip()
